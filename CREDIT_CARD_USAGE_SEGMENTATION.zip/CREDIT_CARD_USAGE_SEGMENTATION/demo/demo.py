# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 20:27:32 2025

@author: saura
"""
import numpy as np
import pandas as pd

# Number of synthetic entries
num_entries = 500

# Seed for reproducibility
np.random.seed(42)

# Generate synthetic data for all features except CUST_ID
data = {
    'BALANCE': np.random.uniform(0, 5000, num_entries),
    'BALANCE_FREQUENCY': np.random.uniform(0, 1, num_entries),
    'PURCHASES': np.random.uniform(0, 3000, num_entries),
    'ONEOFF_PURCHASES': np.random.uniform(0, 1500, num_entries),
    'INSTALLMENTS_PURCHASES': np.random.uniform(0, 2000, num_entries),
    'CASH_ADVANCE': np.random.uniform(0, 1000, num_entries),
    'PURCHASES_FREQUENCY': np.random.uniform(0, 1, num_entries),
    'ONEOFF_PURCHASES_FREQUENCY': np.random.uniform(0, 1, num_entries),
    'PURCHASES_INSTALLMENTS_FREQUENCY': np.random.uniform(0, 1, num_entries),
    'CASH_ADVANCE_FREQUENCY': np.random.uniform(0, 1, num_entries),
    'CASH_ADVANCE_TRX': np.random.randint(0, 10, num_entries),
    'PURCHASES_TRX': np.random.randint(0, 50, num_entries),
    'CREDIT_LIMIT': np.random.choice([1000, 2500, 5000, 7500, 10000], num_entries),
    'PAYMENTS': np.random.uniform(0, 7000, num_entries),
    'MINIMUM_PAYMENTS': np.random.uniform(0, 2000, num_entries),
    'PRC_FULL_PAYMENT': np.random.uniform(0, 1, num_entries),
    'TENURE': np.random.randint(6, 36, num_entries)
}

# Create DataFrame
df_synthetic_no_id = pd.DataFrame(data)

# Save to CSV without index column
df_synthetic_no_id.to_csv('synthetic_customer_data_no_custid.csv', index=False)

print("Synthetic dataset without CUST_ID column created as 'synthetic_customer_data_no_custid.csv'")

