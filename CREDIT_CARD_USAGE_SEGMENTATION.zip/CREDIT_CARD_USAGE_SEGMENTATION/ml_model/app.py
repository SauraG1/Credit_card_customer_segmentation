# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 19:50:23 2025

@author: saura
"""

# app.py

import streamlit as st
import pandas as pd
import joblib

# Load saved model and scaler
model = joblib.load("kmeans_model.pkl")
scaler = joblib.load("scaler.pkl")

st.title('Customer Segmentation App')

st.write("""
Upload a CSV file with customer attributes or enter data for a single customer below.
""")

uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file:
    data = pd.read_csv(uploaded_file)
    data_scaled = scaler.transform(data)
    segments = model.predict(data_scaled)
    data['Predicted_Segment'] = segments
    st.write("### Results:")
    st.dataframe(data)
    st.download_button("Download Results", data.to_csv(index=False), "segmented_results.csv")
else:
    # Example manual entry (adjust fields as needed)
    BALANCE = st.number_input('BALANCE', 0.0, 1e7, 1000.0)
    # ...add other fields here...
    if st.button('Predict Segment'):
        input_data = [[BALANCE, ...]] # list all required fields in correct order
        input_scaled = scaler.transform(input_data)
        seg = model.predict(input_scaled)
        st.write('Predicted Segment:', seg[0])
