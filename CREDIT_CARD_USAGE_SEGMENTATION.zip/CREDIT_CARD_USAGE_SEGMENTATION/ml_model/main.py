# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# model_main.py

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import joblib

# 1. Load data
df = pd.read_csv("D:\BIA\CREDIT_CARD_USAGE_SEGMENTATION\Customer Data.csv")
df_clean = df.drop(columns=['CUST_ID'])        # Remove non-numeric id
df_clean = df_clean.fillna(df_clean.median())  # Handle missing values

# 2. Scale features
scaler = StandardScaler()
data_scaled = scaler.fit_transform(df_clean)

# 3. Build clustering model
kmeans = KMeans(n_clusters=4, random_state=42)
clusters = kmeans.fit_predict(data_scaled)

# 4. Assign cluster labels to data
df['Segment'] = clusters

# 5. Persist the model and scaler for deployment
joblib.dump(kmeans, "kmeans_model.pkl")
joblib.dump(scaler, "scaler.pkl")
df.to_csv('segmented_customers.csv', index=False)
print("Model and scaler saved.")
